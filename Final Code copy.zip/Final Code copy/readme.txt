The final code integrating all previous software components including navigation, obstacle avoidance, communications and hovering is to be placed in this folder
